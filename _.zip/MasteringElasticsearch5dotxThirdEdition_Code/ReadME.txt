Chapters 1 and 8 do not have downloadable code or support files
They contain simple commands